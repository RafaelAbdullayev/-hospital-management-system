import tkinter as tk
from tkinter import ttk, messagebox
import pickle
import bcrypt
import re

# Цвета
COLORS = {
    "bg": "#f0f0f0",
    "button": "#4CAF50",
    "button_active": "#45a049",
    "text": "#333333",
    "title": "#2C3E50",
}

class Patient:
    def __init__(self, name, surname, address, phone, email, age, diagnosis):
        self.name = name
        self.surname = surname
        self.address = address
        self.phone = phone
        self.email = email
        self.age = age
        self.diagnosis = diagnosis
        self.complaints = []

# Загрузка данных
def load_users():
    try:
        with open("users.pickle", "rb") as f:
            return pickle.load(f)
    except:
        return [{
            "username": "admin",
            "password": bcrypt.hashpw("admin123".encode(), bcrypt.gensalt()).decode(),
            "role": "admin"
        }]

def save_users():
    with open("users.pickle", "wb") as f:
        pickle.dump(users, f)

def save_patients():
    with open("patients.pickle", "wb") as f:
        pickle.dump(patients, f)

try:
    with open("patients.pickle", "rb") as f:
        patients = pickle.load(f)
except:
    patients = []

users = load_users()

# Интерфейс
main_window = tk.Tk()
main_window.title("Healthcare System")
main_window.geometry("800x600")
main_window.config(bg=COLORS["bg"])

style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", font=("Arial", 12), padding=10,
                background=COLORS["button"], foreground="white")
style.map("TButton", background=[("active", COLORS["button_active"])])


screen_history = []  # Стек экранов

# Полезные функции
def validate_phone(phone):
    return bool(re.match(r"^\+?[1-9]\d{1,14}$", phone))

def validate_email(email):
    return bool(re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", email))

# Навигация
def navigate_back():
    if screen_history:
        previous_screen = screen_history.pop()
        previous_screen()

# Экраны
def show_login_screen():
    for widget in main_window.winfo_children():
        widget.destroy()

    tk.Label(main_window, text="Healthcare System Login", font=("Arial", 24, "bold"),
             bg=COLORS["bg"], fg=COLORS["title"]).pack(pady=50)

    tk.Label(main_window, text="Username:", bg=COLORS["bg"]).pack()
    username_entry = ttk.Entry(main_window)
    username_entry.pack(pady=5)

    tk.Label(main_window, text="Password:", bg=COLORS["bg"]).pack()
    password_entry = ttk.Entry(main_window, show="*")
    password_entry.pack(pady=5)

    def login_action():
        login(username_entry.get(), password_entry.get())

    ttk.Button(main_window, text="Login", width=20, command=login_action).pack(pady=20)
    ttk.Button(main_window, text="Register as New User", width=20, command=show_register_screen).pack()

    screen_history.append(show_login_screen)  # Добавляем экран в историю навигации

def show_register_screen():
    for widget in main_window.winfo_children():
        widget.destroy()

    tk.Label(main_window, text="Register New User", font=("Arial", 24, "bold"),
             bg=COLORS["bg"], fg=COLORS["title"]).pack(pady=50)

    tk.Label(main_window, text="Username:", bg=COLORS["bg"]).pack()
    username_entry = ttk.Entry(main_window)
    username_entry.pack(pady=5)

    tk.Label(main_window, text="Password:", bg=COLORS["bg"]).pack()
    password_entry = ttk.Entry(main_window, show="*")
    password_entry.pack(pady=5)

    tk.Label(main_window, text="Role (admin/user):", bg=COLORS["bg"]).pack()
    role_entry = ttk.Entry(main_window)
    role_entry.pack(pady=5)

    def submit_registration():
        register_user(username_entry.get(), password_entry.get(), role_entry.get())

    ttk.Button(main_window, text="Register", width=20, command=submit_registration).pack(pady=20)

    ttk.Button(main_window, text="Back", width=20, command=navigate_back).pack(pady=5)

    screen_history.append(show_register_screen)  # Добавляем экран в историю навигации

def register_user(username, password, role):
    if not username or not password or not role:
        messagebox.showerror("Error", "All fields are required!")
        return
    if role not in ["admin", "user"]:
        messagebox.showerror("Error", "Role must be 'admin' or 'user'")
        return
    for user in users:
        if user["username"] == username:
            messagebox.showerror("Error", "User already exists!")
            return

    hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    users.append({"username": username, "password": hashed_password, "role": role})
    save_users()
    messagebox.showinfo("Success", "User registered successfully!")
    show_login_screen()

def login(username, password):
    for user in users:
        if user["username"] == username and bcrypt.checkpw(password.encode(), user["password"].encode()):
            if user["role"] == "admin":
                show_admin_panel()
            else:
                messagebox.showerror("Error", "Access denied!")
            return
    messagebox.showerror("Error", "Invalid credentials!")

def show_admin_panel():
    for widget in main_window.winfo_children():
        widget.destroy()

    tk.Label(main_window, text="Admin Panel 🩺", font=("Arial", 24, "bold"),
             bg=COLORS["bg"], fg=COLORS["title"]).pack(pady=50)

    ttk.Button(main_window, text="Add Patient 👨‍⚕️", width=20, command=show_add_patient_screen).pack(pady=10)
    ttk.Button(main_window, text="View Patients 📋", width=20, command=show_patients_screen).pack(pady=10)
    ttk.Button(main_window, text="Logout 🚪", width=20, command=show_login_screen).pack(pady=10)

    ttk.Button(main_window, text="Back", width=20, command=navigate_back).pack(pady=5)

    screen_history.append(show_admin_panel)  # Добавляем экран в историю навигации

def show_add_patient_screen():
    for widget in main_window.winfo_children():
        widget.destroy()

    tk.Label(main_window, text="Add New Patient", font=("Arial", 24, "bold"),
             bg=COLORS["bg"], fg=COLORS["title"]).pack(pady=30)

    labels = ["Name", "Surname", "Address", "Phone", "Email", "Age", "Diagnosis"]
    entries = {}

    for label in labels:
        tk.Label(main_window, text=f"{label}:", bg=COLORS["bg"]).pack()
        entry = ttk.Entry(main_window)
        entry.pack(pady=5)
        entries[label] = entry

    def submit():
        data = [entries[label].get() for label in labels]
        if not all(data):
            messagebox.showerror("Error", "All fields required!")
            return
        if not validate_phone(data[3]):
            messagebox.showerror("Error", "Invalid phone!")
            return
        if not validate_email(data[4]):
            messagebox.showerror("Error", "Invalid email!")
            return
        patients.append(Patient(*data))
        save_patients()
        messagebox.showinfo("Success", "Patient added.")
        show_admin_panel()

    ttk.Button(main_window, text="Add Patient", command=submit).pack(pady=10)
    ttk.Button(main_window, text="Back", command=navigate_back).pack(pady=5)

    screen_history.append(show_add_patient_screen)  # Добавляем экран в историю навигации

def show_patients_screen():
    for widget in main_window.winfo_children():
        widget.destroy()

    tk.Label(main_window, text="Patients List", font=("Arial", 24, "bold"),
             bg=COLORS["bg"], fg=COLORS["title"]).pack(pady=30)

    search_label = tk.Label(main_window, text="Search Patient (Name, Surname, Phone, etc.):", bg=COLORS["bg"])
    search_label.pack()

    search_entry = ttk.Entry(main_window)
    search_entry.pack(pady=5)

    def search_patients():
        query = search_entry.get().lower()
        filtered_patients = [p for p in patients if query in p.name.lower() or
                             query in p.surname.lower() or query in p.phone.lower() or query in p.email.lower()]
        update_patient_list(filtered_patients)

    search_button = ttk.Button(main_window, text="Search", command=search_patients)
    search_button.pack(pady=10)

    def update_patient_list(filtered_patients):
        for widget in main_window.winfo_children():
            if isinstance(widget, ttk.Treeview):
                widget.destroy()

        tree = ttk.Treeview(main_window, columns=("Name", "Surname", "Age", "Diagnosis"), show="headings")
        for col in tree["columns"]:
            tree.heading(col, text=col)
        tree.pack(pady=10, fill="x", padx=20)

        for p in filtered_patients:
            tree.insert("", "end", values=(p.name, p.surname, p.age, p.diagnosis))

        def edit_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showerror("Error", "Select a patient.")
                return
            index = tree.index(selected[0])
            show_edit_patient_screen(index)

        def delete_selected():
            selected = tree.selection()
            if not selected:
                messagebox.showerror("Error", "Select a patient.")
                return
            index = tree.index(selected[0])
            del patients[index]
            save_patients()
            show_patients_screen()

        ttk.Button(main_window, text="Edit Selected ✏️", command=edit_selected).pack(pady=5)
        ttk.Button(main_window, text="Delete Selected 🗑", command=delete_selected).pack(pady=5)

    search_patients()

    ttk.Button(main_window, text="Back", width=20, command=navigate_back).pack(pady=5)

    screen_history.append(show_patients_screen)  # Добавляем экран в историю навигации


def show_edit_patient_screen(index):
    patient = patients[index]
    for widget in main_window.winfo_children():
        widget.destroy()

    tk.Label(main_window, text="Edit Patient", font=("Arial", 24, "bold"),
             bg=COLORS["bg"], fg=COLORS["title"]).pack(pady=30)

    labels = ["Name", "Surname", "Address", "Phone", "Email", "Age", "Diagnosis"]
    entries = {}

    for label in labels:
        tk.Label(main_window, text=f"{label}:", bg=COLORS["bg"]).pack()
        entry = ttk.Entry(main_window)
        entry.pack(pady=5)
        entries[label] = entry
        entry.insert(0, getattr(patient, label.lower()))

    def submit_edit():
        data = [entries[label].get() for label in labels]
        if not all(data):
            messagebox.showerror("Error", "All fields required!")
            return
        if not validate_phone(data[3]):
            messagebox.showerror("Error", "Invalid phone!")
            return
        if not validate_email(data[4]):
            messagebox.showerror("Error", "Invalid email!")
            return
        patient.name, patient.surname, patient.address, patient.phone, patient.email, patient.age, patient.diagnosis = data
        save_patients()
        messagebox.showinfo("Success", "Patient updated.")
        show_patients_screen()

    ttk.Button(main_window, text="Update Patient", command=submit_edit).pack(pady=10)
    ttk.Button(main_window, text="Back", command=navigate_back).pack(pady=5)

    screen_history.append(show_edit_patient_screen)  # Добавляем экран в историю навигации

show_login_screen()
main_window.mainloop()
